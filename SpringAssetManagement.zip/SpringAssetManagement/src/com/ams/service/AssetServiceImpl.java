package com.ams.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ams.bean.Asset;
import com.ams.bean.Request;
import com.ams.bean.UserMaster;
import com.ams.dao.IAssetDao;

@Service
public class AssetServiceImpl implements IAssetService {

	@Autowired
	private IAssetDao idao;
	
	@Override
	public int addAsset(Asset asset) {
		
		return idao.addAsset(asset);
	}

	@Override
	public int raiseRequest(Request request) {
		
		return idao.raiseRequest(request);
	}

	@Override
	public ArrayList<Request> getList() {
		return idao.getList();
	}

	@Override
	public UserMaster login(UserMaster user) {
		
		return idao.login(user);
	}

	@Override
	public ArrayList<Asset> getAssetList() {
		
		return idao.getAssetList();
	}

	@Override
	public Asset getAssetDetail(int assetId) {
		
		return idao.getAssetDetail(assetId);
	}

	@Override
	public int updateAsset(Asset asset) {
		
		return idao.updateAsset(asset);
	}

	
}
